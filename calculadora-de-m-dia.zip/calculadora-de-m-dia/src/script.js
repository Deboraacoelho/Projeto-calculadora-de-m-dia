function calcular () { 
  var nota1Bimestre = parseFloat(document.getElementById("nota1").value);
  var nota2Bimestre = parseFloat(document.getElementById("nota2").value);
  var nota3Bimestre = parseFloat(document.getElementById("nota3").value);
  var nota4Bimestre = parseFloat(document.getElementById("nota4").value);
   
  var media = (nota1Bimestre + nota2Bimestre + nota3Bimestre + nota4Bimestre) / 4;
  var notaFinal = media.toFixed(2);
  var resultado= document.getElementById("resultado");
  
  if (notaFinal >=7) { 
    document.getElementById("teste").innerHTML = "Parabéns, você foi aprovado! Sua média é: " + notaFinal; 
     } else if (notaFinal<7) {
    document.getElementById("teste").innerHTML = "Você foi reprovado! Sua média é: " + notaFinal;    
  } else {
document.getElementById("calculo").onclick = "Calcularnota";
  }
}