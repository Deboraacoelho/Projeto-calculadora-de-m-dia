# Calculadora de média

A Pen created on CodePen.io. Original URL: [https://codepen.io/deboraacoelho/pen/YzYXeVj](https://codepen.io/deboraacoelho/pen/YzYXeVj).

